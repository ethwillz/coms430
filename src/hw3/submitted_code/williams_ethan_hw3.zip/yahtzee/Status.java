package hw3.submitted_code.yahtzee;

public enum Status
{
  START, GENERATING, SCORING, DONE;
}
