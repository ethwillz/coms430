package main

const (
	DefaultNumSamples = 10000000
	DefaultUpperBound = 10000
	DefaultNumWorkers = 4
)
