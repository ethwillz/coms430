package org.codefx.lab.streamperformance;

import org.openjdk.jmh.annotations.Benchmark;

import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Spliterators;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

/**
 * Defines benchmarks that execute a somewhat complex string manipulation.
 * <p>
 * Note that there are no methods special-handling boxing or unboxing since
 * the reduction operation is based on a reference type (String).
 */
public class ComplexOperationsBenchmark extends AbstractIterationBenchmark {

	/*************************************************************
	 *                  Collector Benchmarks					 *
	 *************************************************************/

	@Benchmark
	public Map<String, List<Employee>> serialCollector() {
		return employees.stream()
				.collect(Collectors
						.groupingBy(Employee::getDepartment)
				);
	}

	@Benchmark
	public Map<String, List<Employee>> parallelCollector() {
		return employees.stream()
				.parallel()
				.collect(Collectors
						.groupingBy(Employee::getDepartment)
				);
	}

	@Benchmark
	public Map<String, List<Employee>> parallelThreadSafeCollector() {
		return employees.stream()
				.parallel()
				.collect(Collectors
						.groupingByConcurrent(Employee::getDepartment)
				);
	}

	/*************************************************************
	 *                  Spliterator Benchmarks					 *
	 *************************************************************/

	@Benchmark
	public List<Employee> serialSpliterator(){
		return employees.stream()
				.filter(x -> x.getName().contains("a"))
				.skip(1000)
				.collect(Collectors.toList());
	}

	@Benchmark
	public List<Employee> parallelSpliterator(){
		return employees.stream()
				.parallel()
				.filter(x -> x.getName().contains("a"))
				.skip(1000)
				.collect(Collectors.toList());
	}

	/*************************************************************
	 *                 Long-Running Benchmarks					 *
	 *************************************************************/

	@Benchmark
	public String serialLongOps(){
		return randomStrings.stream().map(x -> longOperation()).findAny().orElse(null);
	}

	@Benchmark
	public String parallelLongOps(){
		return randomStrings.parallelStream().map(x -> longOperation()).findAny().orElse(null);
	}

	private static String longOperation(){
		try {
			Thread.sleep(3500);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		return "";
	}
}
